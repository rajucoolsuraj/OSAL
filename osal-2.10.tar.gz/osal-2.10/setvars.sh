#
# setvars.sh 
#
# This shell script is used to set the OSAL_SRC environment variable for the makefile
#
cd src
export OSAL_SRC=`pwd`
cd ..
