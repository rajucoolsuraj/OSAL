sudo /opt/rtems-4.7/bin/m68k-bdm-rtems-gdb --command=../gdb-bcc2.init test1.nxe
